export type ICreateUsersBody = {
	name: string,
	email: string,
	petType: string
}
